开始使用
-----------------------------------------
欢迎使用全新的 Mobile Backend！

将 Mobile Backend 模板用作起点，并且如果您已经设置开发环境，请使用以下简单步骤入门：

1. [下载起动器应用程序包](${ace-url}/rest/apps/${app-guid}/starter-download)
2. 下载 [SDK](${doc-url}/#starters/mobile/sdk.html)
3. 按需要修改起动器应用程序包
4. 使用[命令行界面](https://github.com/cloudfoundry/cli)来推送回已更新的应用程序
