Guia de Introdução de abertura
-----------------------------------------
Parabéns pelo novo Mobile Backend!

Para usar o modelo Mobile Backend como ponto de partida, e se você já tiver um ambiente de desenvolvimento configurado, inicie com estas etapas simples:

1. [faça o download do pacote de aplicativos inicializador](${ace-url}/rest/apps/${app-guid}/starter-download)
2. Faça o download dos [SDKs](${doc-url}/#starters/mobile/sdk.html)
3. Modifique o pacote de aplicativos inicializador conforme necessário
4. Usando a [Interface de linha de comandos cf](https://github.com/cloudfoundry/cli) para retornar por push o aplicativo atualizado
