Apri guida introduttiva
-----------------------------------------
Benvenuti nel nuovo Mobile Backend.

Per utilizzare il template Mobile Backend come punto di partenza, e se si dispone già di un ambiente di sviluppo configurato, è possibile completare questa semplice procedura:

1. [Scaricare il package di applicazione starter](${ace-url}/rest/apps/${app-guid}/starter-download)
2. Scaricare gli [SDK](${doc-url}/#starters/mobile/sdk.html)
3. Modificare il package di applicazione starter in base alle necessità
4. Utilizzo dell'[Interfaccia riga di comando cf](https://github.com/cloudfoundry/cli) per ridistribuire l'applicazione aggiornata
