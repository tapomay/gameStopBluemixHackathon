開始使用
-----------------------------------------
歡迎使用全新的 Mobile Backend！

如果要使用 Mobile Backend 範本作為起始點，而且您已經設定開發環境，請透過以下簡單的步驟開始：

1. [下載入門範本應用程式套件](${ace-url}/rest/apps/${app-guid}/starter-download)
2. 下載 [SDK](${doc-url}/#starters/mobile/sdk.html)
3. 依需要修改入門範本應用程式套件
4. 使用[指令行介面](https://github.com/cloudfoundry/cli)來推送回已更新的應用程式
